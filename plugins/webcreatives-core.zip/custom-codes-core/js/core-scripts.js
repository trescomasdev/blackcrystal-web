jQuery(function($) {
	$( ".accordion" ).each(function( index ) {
		$(this).accordion();
	});	
});