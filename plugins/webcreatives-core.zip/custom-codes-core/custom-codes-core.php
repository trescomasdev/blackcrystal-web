<?php
/*
Plugin Name: Custom Codes Core
Plugin URI: 
Description: 
Version: 1.0
Author: Peter Bartfai
Author URI: 
License: GPL2
*/
/*
Copyright 2015
*/
require 'plugin-updates/plugin-update-checker.php';
$ExampleUpdateChecker = PucFactory::buildUpdateChecker(
	'http://cube3.hu/custom-codes-core-update/custom-codes-core-update.json',
	__FILE__
);
	
if(!class_exists('CCCore')) {
	
	class CCCore{
		
		public function __construct(){
			//add_action('admin_menu', array(&$this, 'create_pages'));		
			//add_action('admin_init', array(&$this, 'register_settings') );		
			//add_action('admin_enqueue_scripts', array(&$this, 'admin_scripts'));	
			//add_action('wp_enqueue_scripts', array(&$this, 'front_scripts'));		
			add_action( 'login_form', array(&$this, 'login_fields') );				
			add_action ('wp_authenticate' , array(&$this, 'check_custom_authentication'));
			$this->init();					
		}
		
		public function init(){
			$this->get_dir('class');
			$this->get_addon('post-types');
			$this->get_addon('addons');
				
		}
		
        public static function activate(){
            // Do nothing
        } // END public static function activate
    
        /**
         * Deactivate the plugin
         */     
        public static function deactivate(){
            // Do nothing
        } // END public static function deactivate		
		
		public function get_dir($dirname, $all = true){
			foreach (glob(dirname(__FILE__) . '/'. $dirname . '/*.{php}', GLOB_BRACE) as $filename) {
				    $adds = explode("/", $filename);
					include $filename;	  
			}						
		}	
		
		public function get_addon($dirname, $folders = true){
			foreach (glob(dirname(__FILE__) . '/'. $dirname . '/*.{php}', GLOB_BRACE) as $filename) {
				    $adds = explode("/", $filename);
					include $filename;	  
			}	
											
			if ($folders == true){
				foreach (glob(dirname(__FILE__) . '/'. $dirname . '/*', GLOB_ONLYDIR) as $filename) {
					    $adds = explode("/", $filename);
						include $filename . '/' . end($adds) . '.php';	 
				}	
			}
		}		
		
		
		public function admin_scripts() {

		}
		
		
		public function front_scripts(){
			//wp_enqueue_script('jquery-tms', get_template_directory_uri().'/js/tms-slider.js', array('jquery') );
		}		
		
		public function create_pages(){
			add_menu_page('Téma beállítások', 'Téma beállítások', 'administrator', __FILE__, array(&$this, 'theme_settings_page'),'dashicons-welcome-view-site');			
		}
		
		function login_fields() {
		
			echo '<div class="QapTcha"></div>';
			echo '<script type="text/javascript">
				jQuery(document).ready(function($){
					$(".QapTcha").QapTcha({txtLock : "Csúsztasd el a bejelentkezéshez", txtUnlock : "Feloldva", disabledSubmit: false, autoSubmit: true});
				});
			</script>';

		}		
		
		public function logout_url(){
		  wp_redirect( home_url() );
		  exit();
		}		
		
		public function theme_settings_page(){
			include(sprintf("%s/admin-templates/theme-options.php", dirname(__FILE__)));	
		}
		
		public function register_settings(){
			register_setting('theme-group', 'twitter'); 
			register_setting('theme-group', 'facebook'); 
			register_setting('theme-group', 'gplus'); 
			register_setting('theme-group', 'header_text_1'); 
			register_setting('theme-group', 'header_text_2'); 
			register_setting('theme-group', 'footer_text'); 		
		}	
		
		function check_custom_authentication ($username) {
	        global $wpdb;
			session_start();
	
	        if (!username_exists($username)) {
		         return;
	        }
	        
			if ($_POST == array()) {
				return true;
			}
			
			// check if $_SESSION['qaptcha_key'] created with AJAX exists
			if(isset($_SESSION['qaptcha_key']) && !empty($_SESSION['qaptcha_key'])){
				$myVar = $_SESSION['qaptcha_key'];
				// check if the random input created exists and is empty
				if(isset($_POST[''.$myVar.'']) && empty($_POST[''.$myVar.''])){
					unset($_SESSION['qaptcha_key']);
				} else{
					header('Location: wp-login.php?login_qatcha_err=1');
					exit();
				}
			} else {
				header('Location: wp-login.php?login_qatcha_err=1');
				exit();
			}				


		}		
		
	} //End CCCore Class
}

if(class_exists('CCCore')){
    // Installation and uninstallation hooks
    register_activation_hook(__FILE__, array('CCCore', 'activate'));
    register_deactivation_hook(__FILE__, array('CCCore', 'deactivate'));

    // instantiate the plugin class
    $CCCore = new CCCore();
}

add_filter( 'post_thumbnail_html', 'attachment_thumbnail', 10, 5);
function attachment_thumbnail($html, $post_id, $post_thumbnail_id, $size, $attr ){
	if (get_post_type($post_id) == 'attachment' && get_post_mime_type($post_id) != 'video/x-flv'){	
		$html = wp_get_attachment_image( $post_id, $size, false, $attr );
	}
	
	if (get_post_type($post_id) == 'attachment' && get_post_mime_type($post_id) == 'video/x-flv'){
		$html = '<iframe src="'.wp_get_attachment_url($post_id).'" width="560" height="315" frameborder="0" allowfullscreen></iframe>';		
	}
	
	return $html;
}
?>
