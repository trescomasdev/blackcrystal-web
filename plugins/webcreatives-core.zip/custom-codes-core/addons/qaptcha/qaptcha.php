<?php 
	if(!class_exists('QAPTCHA')) {

	    class QAPTCHA {
	    
		    public function __construct(){	
				add_action('wp_login', array(&$this, 'EndSession'));
				add_action('wp_logout', array(&$this, 'EndSession'));
				add_action( 'wp_enqueue_scripts', array(&$this, 'front_scripts'));
				add_action( 'login_enqueue_scripts', array(&$this, 'front_scripts'));
		    }	
		    				
			public function startSession() {
			    if(!session_id()) {
			        session_start();
			    }
			}
		
			public function EndSession() {
			    session_destroy ();
			}	
			
			public function front_scripts(){
				wp_enqueue_script( 'jquery');
				wp_enqueue_script( 'jquery-ui-draggable');
				wp_enqueue_script( 'jquery-ui-touch', plugins_url( 'js/jquery.ui.touch.js', __FILE__ ),  array('jquery'));
				wp_enqueue_script( 'QapTcha.jquery-jquery', plugins_url( 'js/QapTcha.jquery.js', __FILE__ ),  array('jquery'), '1.0', true);
				wp_localize_script( 'QapTcha.jquery-jquery', 'ajax_urls',	array( 'admin_url' => plugins_url( '', __FILE__ ) ) );			
				
				wp_enqueue_style( 'quaptcha', plugins_url( 'css/QapTcha.jquery.css', __FILE__ ));					
			}		    								
		}
	}
	
	if (class_exists('QAPTCHA')){
		$QAPTCHA = new QAPTCHA();
	}
?>