<?php
if(!class_exists('CCSliders')) {
	
class CCSliders{
		
		public function __construct(){
			$this->init();								
			/* Filter the single_template with our custom function*/
			add_filter('single_template', array(&$this, 'custom_single_template'));	
			add_action( 'admin_enqueue_scripts', array(&$this, 'admin_scripts' ));	
		}
		
		public function init(){
			$this->get_dir('class');
			$this->get_dir('post-types');
		}
		
		public function get_dir($dirname, $all = true){
			foreach (glob(dirname(__FILE__) . '/'. $dirname . '/*.{php}', GLOB_BRACE) as $filename) {
				    $adds = explode("/", $filename);
					include $filename;	  
			}						
		}	
		
		public function get_addon($dirname, $folders = true){
			foreach (glob(dirname(__FILE__) . '/'. $dirname . '/*.{php}', GLOB_BRACE) as $filename) {
				    $adds = explode("/", $filename);
					include $filename;	  
			}	
											
			if ($folders == true){
				foreach (glob(dirname(__FILE__) . '/'. $dirname . '/*', GLOB_ONLYDIR) as $filename) {
					    $adds = explode("/", $filename);
						include $filename . '/' . end($adds) . '.php';	 
				}	
			}
		}	

		function custom_single_template($single) {
		    global $wp_query, $post;
		
		/* Checks for single template by post type */
		if ($post->post_type == "sliders"){
			$filename = dirname(__FILE__) . '/templates/single-slider.php';
		    if(file_exists($filename))
		        return $filename;
		}
		    return $single;
		}			
		
		public function admin_scripts() {
			if ($this->get_current_post_type() == 'sliders'){			
				wp_enqueue_style('cc-slider-admin', plugins_url( './css/cc-slider-admin.css', __FILE__ ));
				wp_enqueue_script('autocomplete');
				wp_enqueue_script('cc-slider-admin', plugins_url( './js/cc-slider-admin.js', __FILE__ ), array('jquery') );
			}
		}
		
		public function front_scripts(){
		
		}	
		
		function get_current_post_type() {
		  global $post, $typenow, $current_screen;
			
		  //we have a post so we can just get the post type from that
		  if ( $post && $post->post_type )
		    return $post->post_type;
		    
		  //check the global $typenow - set in admin.php
		  elseif( $typenow )
		    return $typenow;
		    
		  //check the global $current_screen object - set in sceen.php
		  elseif( $current_screen && $current_screen->post_type )
		    return $current_screen->post_type;
		  
		  //lastly check the post_type querystring
		  elseif( isset( $_REQUEST['post_type'] ) )
		    return sanitize_key( $_REQUEST['post_type'] );
			
		  //we do not know the post type!
		  return null;
		}			
		
	}
}

if(class_exists('CCSliders')){
    // instantiate the plugin class
    $CCSliders = new CCSliders();
}
?>
