  jQuery(function($) {   
	$('.remove_element').click(function (){
		var element = $(this).closest('.element');
		var id = $(this).attr('data-id');
		
	    $.ajax({
	        url: "/wp-content/plugins/custom-codes-core/addons/sliders/lib/ajax.php",
	        data: {
	            'action':'slider_remove_element',
	            'id' : id,
	        },
	        method: 'POST',
	        success:function(data) {
	            // This outputs the result of the ajax request
	            if (data == 1){
		            element.remove();
	            }
	        },
	        error: function(errorThrown){
	            console.log(errorThrown);
	        }
	    }); 		
	});
    
    $( "#slider_elements" ).sortable({
	    update: function( event, ui ) {
		    var data = $(this).sortable('toArray');
		    $.ajax({
		        url: "/wp-content/plugins/custom-codes-core/addons/sliders/lib/ajax.php",
		        data: {
		            'action':'slider_order_objects',
		            'data' : data
		        },
		        method: 'POST',
		        success:function(data) {
		            // This outputs the result of the ajax request
		            console.log(data);
		        },
		        error: function(errorThrown){
		            console.log(errorThrown);
		        }
		    });  
	    }
    });
    $( "#slider_elements" ).disableSelection();
  });