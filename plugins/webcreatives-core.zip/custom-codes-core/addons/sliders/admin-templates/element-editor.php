<input type="text" class="autocomplete" data-id="<?php the_ID();?>" placeholder="keresés" data-action="add_slider_object"/>
<div id="myDiv"></div>
<div class="slider_editor_holder">
	<!--
	<div class="slider_editor_nav_holder">
		<ul class="slider_editor_nav">
			<li>
				<a id="slider_add_static_element">
					<span class="dashicons dashicons-plus-alt"></span>
					<label><?php _e('Add new static element', 'custom-codes-core-textdomain')?></label>
				</a>
			</li>
			<li>
				<a id="slider_add_page">			
					<span class="dashicons dashicons-plus-alt"></span>
					<label><?php _e('Add new page', 'custom-codes-core-textdomain')?></label>	
				</a>		
			</li>
		</ul>
		<br clear="all">
	</div>
	-->
	<div class="slider_editor_elements">
	<?php $objects = CCSlidersAdmin::get_slider_objects(get_the_ID());?>
		<ul id="slider_elements">
			<?php foreach($objects as $object): ?>
				<?php CCSlidersAdmin::slider_create_object_html($object) ?>
		    <?php endforeach;?>
		</ul>
	</div>
</div>