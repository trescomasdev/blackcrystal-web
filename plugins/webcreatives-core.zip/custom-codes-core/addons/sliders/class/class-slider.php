<?php
if(!class_exists('CCSlider')) {
	
class CCSlider{
		
		public function __construct($sliderID, $query_args = array()){
			$this->ID = $sliderID;
			$this->query =  $this->get_query($sliderID, $query_args);
		}

		function get_object_ids($sliderID){
			global $wpdb;
			
			$results = $wpdb->get_results( "SELECT objectID FROM wp_slider_relations WHERE sliderID = $sliderID ORDER BY list_order ASC", ARRAY_A );
			foreach( $results as $result )
			$ids[] = $result['objectID'];
			
			return $ids;
		}	
		
		function get_objects($sliderID){
			global $wpdb;
			
			$results = $wpdb->get_results( "SELECT * FROM wp_slider_relations WHERE sliderID = $sliderID ORDER BY list_order ASC", ARRAY_A );
			
			return $results;
		}	
		
		function get_query($sliderID, $query_args){
			global $wpdb;
			
			$object_ids = $this->get_object_ids($sliderID);
			
			$defaults = array(
				'post__in' => $object_ids,
				'post_type' => 'any',
				'post_status' => 'any',
				'posts_per_page' => -1,
			);
			
			$args = array_merge($defaults, $query_args);
			
			$slider = new WP_Query($args);	
			
			return $slider;
		}	
	}
}
?>
