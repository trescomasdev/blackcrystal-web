<?php
if(!class_exists('CCSlidersAdmin')) {
	
class CCSlidersAdmin{
		
		public function __construct(){
					
		}
		
		function slider_create_object_html($object){
			$value = ($object['value'] != "" ? $object['value'] : get_the_title($object['objectID']));
			echo '<li id="element-'.$object['id'].'" class="element">
				    	<div class="left">
				    		<div class="element_title">'.$value.' - <span>'.get_post_type($object['objectID']).'</span></div>
				    	</div>
				    	<div class="right">
				    		<div class="element_actions">
				    			<a class="remove_element" data-id="'.$object['id'].'">
				    				<span class="dashicons dashicons-trash"></span>
				    			</a>
				    		</div>	
				    	</div>	
				    	<br clear="all">	    
				 </li>';	
		}	
		
		public function get_slider_objects($sliderID){
			global $wpdb;
			
			$results = $wpdb->get_results( "SELECT * FROM wp_slider_relations WHERE sliderID = $sliderID ORDER BY list_order ASC", ARRAY_A );
			
			return $results;
		}		
	}
}
?>
