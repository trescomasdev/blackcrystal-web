<?php
class SlidersPostType {

    /**
    * hooks
    */
    public function __construct() {
        add_action('init', array($this, 'register'));
        add_action( 'save_post', array( $this, 'save_metabox' ) );
        //add_action('save_post', array(&$this, 'save_metabox'), 1, 2); // save the custom fields

    }

    /**
    * admin_init action
    */
    public function init() {

    }

    /**
    * register Custom Post Type
    */
    public function register() {
    
		$labels = array(
			'name'                => _x( 'Sliders', 'Post Type General Name', 'custom-codes-core-textdomain' ),
			'singular_name'       => _x( 'Slider', 'Post Type Singular Name', 'custom-codes-core-textdomain' ),
			'menu_name'           => __( 'Sliders', 'custom-codes-core-textdomain' ),
			'name_admin_bar'      => __( 'Slider', 'custom-codes-core-textdomain' ),
			'parent_item_colon'   => __( 'Parent Item:', 'custom-codes-core-textdomain' ),
			'all_items'           => __( 'All Items', 'custom-codes-core-textdomain' ),
			'add_new_item'        => __( 'Add New Item', 'custom-codes-core-textdomain' ),
			'add_new'             => __( 'Add New', 'custom-codes-core-textdomain' ),
			'new_item'            => __( 'New Item', 'custom-codes-core-textdomain' ),
			'edit_item'           => __( 'Edit Item', 'custom-codes-core-textdomain' ),
			'update_item'         => __( 'Update Item', 'custom-codes-core-textdomain' ),
			'view_item'           => __( 'View Item', 'custom-codes-core-textdomain' ),
			'search_items'        => __( 'Search Item', 'custom-codes-core-textdomain' ),
			'not_found'           => __( 'Not found', 'custom-codes-core-textdomain' ),
			'not_found_in_trash'  => __( 'Not found in Trash', 'custom-codes-core-textdomain' ),
		);    
        // register the post type
        register_post_type('sliders', array(
		
			'labels'=> $labels,
            'description' => __('Hirdetések', 'adojog-theme'),
            'exclude_from_search' => true,
            'publicly_queryable' => true,
            'public' => true,
            'show_ui' => true,
            'auto-draft' => false,
            'show_in_admin_bar' => true,
            'show_in_nav_menus' => true,
            'menu_position' => 4,
            'menu_icon'	=> 'dashicons-images-alt',
            'revisions' => false,
            'hierarchical' => true,
            'has_archive' => true,
			'supports' => array('title'),
            'rewrite' => false,
            'can_export' => false,
            'capability_type' => 'page',
            'register_meta_box_cb' => array(&$this, 'add_metabox')               
        ));
    }
    
    public function add_metabox(){
	    add_meta_box('elements', 'Elements', array(&$this, 'metabox'), 'sliders','normal');
    }
    
    public function metabox($post){
	   include(sprintf("%s/admin-templates/element-editor.php", dirname(dirname(__FILE__))));
    }
    
    public function save_metabox($post_id){
		// Check if our nonce is set.
		if ( ! isset( $_POST['url_metabox_nonce'] ) )
			return $post_id;

		$nonce = $_POST['url_metabox_nonce'];

		// Verify that the nonce is valid.
		if ( ! wp_verify_nonce( $nonce, 'url_metabox' ) )
			return $post_id;

		// If this is an autosave, our form has not been submitted,
                //     so we don't want to do anything.
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) 
			return $post_id;

		// Check the user's permissions.
		if ( 'page' == $_POST['post_type'] ) {

			if ( ! current_user_can( 'edit_page', $post_id ) )
				return $post_id;
	
		} else {

			if ( ! current_user_can( 'edit_post', $post_id ) )
				return $post_id;
		}

		/* OK, its safe for us to save the data now. */

		// Sanitize the user input.
		$mydata = sanitize_text_field( $_POST['slider_url'] );

		// Update the meta field.
		update_post_meta( $post_id, 'slider_url', $mydata );
	    
    }
    
 }
$SlidersPostType = new SlidersPostType();




?>
